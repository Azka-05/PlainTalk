/* PlainTalk — Patient Logic */

document.addEventListener('DOMContentLoaded', () => {
    seedDemoData();
    loadPatientData();
    updateTimeGreeting();
    loadModePreference();
    startReminderChecker();
    setInterval(updateTimeGreeting, 60000);
    setInterval(checkReminders, 10000);
});

// ============ SEED DEMO DATA ============
function seedDemoData() {
    if (localStorage.getItem('plaintalk_admin')) return; // already has data
    const demo = {
        patientName: 'Eileen',
        emergencyContact: 'tel:+441234567890',
        music: {
            selectedSong: { name: 'Calm Piano', url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3' }
        },
        album: {
            photos: [
                'https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=400&h=400&fit=crop',
                'https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=400&h=400&fit=crop',
                'https://images.unsplash.com/photo-1474176857210-7287d38d27c6?w=400&h=400&fit=crop',
                'https://images.unsplash.com/photo-1517483000871-1dbf64a6e1c6?w=400&h=400&fit=crop',
                'https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=400&h=400&fit=crop',
                'https://images.unsplash.com/photo-1501594907352-04cda38ebc29?w=400&h=400&fit=crop'
            ]
        },
        activity: {
            title: 'Painting a Flower 🌸',
            steps: [
                'Get the paints from the cupboard beneath the mirror.',
                'Put some old newspaper on the table.',
                'Fill a small cup with water.',
                'Pick a colour you like.',
                'Paint a flower on the paper. Any flower is fine!',
                'Let it dry for 10 minutes.',
                'Show it to someone you love!'
            ]
        },
        reading: {
            newspapers: [
                {
                    title: 'Sunny Weather This Week',
                    content: 'It will be warm and sunny this week.\nThe sun will shine every day.\nIt might rain a little on Friday.\nBut Saturday will be lovely again.\nA good week to go outside!'
                },
                {
                    title: 'New Park Opens in Town',
                    content: 'A new park has opened near the shops.\nIt has benches to sit on.\nThere are flowers and big trees.\nChildren can play on the swings.\nIt is a nice place to visit.'
                },
                {
                    title: 'Local Dog Show This Weekend',
                    content: 'There is a dog show on Saturday.\nLots of dogs will be there.\nBig dogs and small dogs.\nYou can watch them do tricks.\nThere will be tea and cake too.'
                }
            ],
            books: [
                {
                    title: 'The Sleepy Little Star',
                    content: 'Once upon a time, there was a little star.\nThe little star lived high up in the sky.\nEvery night, it would shine so bright.\n\n"Time to sleep," said the moon.\n\nThe little star closed its eyes.\nIt dreamed of sunny days.\nAnd fluffy white clouds.\n\nGoodnight, little star.\nSleep well until tomorrow.'
                },
                {
                    title: 'The Friendly Cat',
                    content: 'There was a cat called Mittens.\nMittens had soft white fur.\nShe liked to sit by the window.\n\nOne day, a bird came to visit.\n"Hello!" said the bird.\n"Hello!" said Mittens.\n\nThey sat together in the sun.\nThey were very happy.\n\nThe end.'
                },
                {
                    title: 'The Rainbow Garden',
                    content: 'In a little garden, flowers grew.\nRed ones and blue ones.\nYellow ones and pink ones.\n\nA butterfly came to visit.\nIt sat on every flower.\n\n"How pretty!" said the butterfly.\n"Thank you!" said the flowers.\n\nThe sun smiled down on them all.\nWhat a lovely day.'
                }
            ]
        },
        reminders: [
            { time: '10:00', text: 'Feed the dog and drink some water 💧', completed: false },
            { time: '12:00', text: 'Time to eat some food! 🍽️', completed: false },
            { time: '13:00', text: 'Go on a nice walk! 🚶', completed: false },
            { time: '17:00', text: 'Take your medicine 💊', completed: false }
        ],
        patientInfo: { name: 'Eileen Smith', age: '80', diagnosis: 'Early-stage dementia', notes: '' },
        usage: { music: 12, album: 8, activity: 5, reading: 15 }
    };
    localStorage.setItem('plaintalk_admin', JSON.stringify(demo));
}

// ============ DATA ============
function getData() {
    try { return JSON.parse(localStorage.getItem('plaintalk_admin')); }
    catch { return null; }
}

function loadPatientData() {
    const d = getData();
    if (!d) return;
    document.getElementById('greeting').textContent = 'Hello, ' + d.patientName;
    document.getElementById('callBtn').onclick = () => {
        if (d.emergencyContact) window.location.href = d.emergencyContact;
        else alert('No emergency contact set yet.');
    };
}

// ============ TIME ============
function updateTimeGreeting() {
    const h = new Date().getHours();
    const el = document.getElementById('timeGreeting');
    if (h < 12) el.textContent = 'Good morning ☀️';
    else if (h < 17) el.textContent = 'Good afternoon 🌤️';
    else el.textContent = 'Good evening 🌙';
}

// ============ MODE ============
function loadModePreference() {
    const m = localStorage.getItem('plaintalk_mode');
    document.body.classList.remove('light-mode', 'dark-mode');
    document.body.classList.add(m === 'dark' ? 'dark-mode' : 'light-mode');
}
document.getElementById('modeToggle').addEventListener('click', () => {
    const isDark = document.body.classList.contains('dark-mode');
    document.body.classList.remove('light-mode', 'dark-mode');
    document.body.classList.add(isDark ? 'light-mode' : 'dark-mode');
    localStorage.setItem('plaintalk_mode', isDark ? 'light' : 'dark');
});

// ============ PANELS ============
function openPanel(id) {
    document.getElementById(id).classList.add('active');
    document.body.style.overflow = 'hidden';
    // Track usage
    const d = getData();
    if (d) {
        if (!d.usage) d.usage = { music:0, album:0, activity:0, reading:0 };
        const key = id.replace('Panel','');
        if (d.usage[key] !== undefined) d.usage[key]++;
        localStorage.setItem('plaintalk_admin', JSON.stringify(d));
    }
}
function closePanel(id) {
    document.getElementById(id).classList.remove('active');
    document.body.style.overflow = '';
    if (id === 'musicPanel') {
        const a = document.getElementById('audioPlayer');
        if (a) a.pause();
        updatePlayIcon(false);
    }
}

// ============ MUSIC ============
let isPlaying = false;
function openMusic() {
    const d = getData();
    const song = d?.music?.selectedSong;
    if (song && song.url) {
        document.getElementById('musicNowPlaying').textContent = '🎶 Now Playing:';
        document.getElementById('musicSongName').textContent = song.name;
        document.getElementById('musicControls').style.display = 'block';
        document.getElementById('audioPlayer').src = song.url;
    } else {
        document.getElementById('musicNowPlaying').textContent = 'No song chosen yet.';
        document.getElementById('musicControls').style.display = 'none';
    }
    openPanel('musicPanel');
}
function togglePlay() {
    const a = document.getElementById('audioPlayer');
    if (!a.src) return;
    if (isPlaying) a.pause(); else a.play().catch(()=>{});
    isPlaying = !isPlaying;
    updatePlayIcon(isPlaying);
}
function updatePlayIcon(p) {
    document.getElementById('playIcon').style.display = p ? 'none' : 'block';
    document.getElementById('pauseIcon').style.display = p ? 'block' : 'none';
    isPlaying = p;
}

// ============ ALBUM ============
function openAlbum() {
    const d = getData();
    const g = document.getElementById('albumGrid');
    const photos = d?.album?.photos || [];
    if (photos.length === 0) { g.innerHTML = '<p>No photos yet.</p>'; }
    else { g.innerHTML = photos.map(u => '<img src="'+u+'" alt="Photo" loading="lazy">').join(''); }
    openPanel('albumPanel');
}

// ============ ACTIVITY ============
function openActivity() {
    const d = getData();
    const c = document.getElementById('activitySteps');
    const a = d?.activity;
    if (!a || !a.steps || a.steps.length === 0) {
        c.innerHTML = '<p>No activity set yet.</p>';
    } else {
        c.innerHTML = '<div class="activity-title-display">' + esc(a.title || 'Activity') + '</div>' +
            a.steps.map((s,i) =>
                '<div class="activity-step"><div class="step-number">'+(i+1)+'</div><div class="step-text">'+esc(s)+'</div></div>'
            ).join('');
    }
    openPanel('activityPanel');
}

// ============ READING ============
function openReading() {
    const d = getData();
    const c = document.getElementById('readingContent');
    const isDark = document.body.classList.contains('dark-mode');

    if (isDark) {
        const books = d?.reading?.books || [];
        if (books.length === 0) { c.innerHTML = '<p>No stories yet.</p>'; }
        else {
            c.innerHTML = books.map(b =>
                '<div class="reading-article"><h3>📖 '+esc(b.title)+'</h3><p>'+esc(b.content)+'</p></div>'
            ).join('');
        }
    } else {
        const news = d?.reading?.newspapers || [];
        if (news.length === 0) { c.innerHTML = '<p>No news yet.</p>'; }
        else {
            c.innerHTML = news.map(a =>
                '<div class="reading-article"><h3>📰 '+esc(a.title)+'</h3><p>'+esc(a.content)+'</p></div>'
            ).join('');
        }
    }
    openPanel('readingPanel');
}

// ============ REMINDERS ============
let dismissed = new Set();
function startReminderChecker() {
    const s = sessionStorage.getItem('plaintalk_dismissed');
    if (s) try { dismissed = new Set(JSON.parse(s)); } catch {}
    checkReminders();
}
function checkReminders() {
    const d = getData();
    if (!d) return;
    const now = new Date();
    const mins = now.getHours() * 60 + now.getMinutes();
    for (const r of (d.reminders || [])) {
        const [h,m] = r.time.split(':').map(Number);
        const rm = h * 60 + m;
        const key = r.time + '-' + r.text;
        if (Math.abs(mins - rm) <= 2 && !dismissed.has(key) && !r.completed) {
            showReminder(r, key);
            return;
        }
    }
}
function showReminder(r, key) {
    const t = r.text.toLowerCase();
    let icon = '⏰';
    if (t.includes('medicine') || t.includes('pill')) icon = '💊';
    else if (t.includes('water') || t.includes('drink')) icon = '💧';
    else if (t.includes('eat') || t.includes('food') || t.includes('lunch')) icon = '🍽️';
    else if (t.includes('walk')) icon = '🚶';
    else if (t.includes('bed') || t.includes('sleep')) icon = '🛏️';
    else if (t.includes('dog')) icon = '🐕';

    document.getElementById('reminderIcon').textContent = icon;
    document.getElementById('reminderTitle').textContent = r.text;
    document.getElementById('reminderDesc').textContent = 'Please do this now.';
    document.getElementById('reminderOverlay').classList.add('active');

    document.getElementById('reminderDoneBtn').onclick = () => {
        document.getElementById('reminderOverlay').classList.remove('active');
        dismissed.add(key);
        sessionStorage.setItem('plaintalk_dismissed', JSON.stringify([...dismissed]));
        // Mark complete
        const d = getData();
        const idx = d.reminders.findIndex(x => x.time === r.time && x.text === r.text);
        if (idx >= 0) { d.reminders[idx].completed = true; localStorage.setItem('plaintalk_admin', JSON.stringify(d)); }
    };
}

function esc(s) { const d = document.createElement('div'); d.textContent = s; return d.innerHTML; }
