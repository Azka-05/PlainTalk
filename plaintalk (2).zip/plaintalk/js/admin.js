/* PlainTalk — Admin Logic */

const SONGS = [
    { name: 'Calm Piano', url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3' },
    { name: 'Nature Sounds', url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3' },
    { name: 'Classic Jazz', url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3' }
];

function getData() {
    const r = localStorage.getItem('plaintalk_admin');
    if (!r) return defaultData();
    try { return JSON.parse(r); } catch { return defaultData(); }
}
function save(d) { localStorage.setItem('plaintalk_admin', JSON.stringify(d)); }
function defaultData() {
    return { patientName:'Eileen', emergencyContact:'', music:{selectedSong:null}, album:{photos:[]}, activity:{title:'',steps:[]}, reading:{newspapers:[],books:[]}, reminders:[], patientInfo:{name:'',age:'',diagnosis:'',notes:''}, usage:{music:0,album:0,activity:0,reading:0} };
}
function esc(s) { const d=document.createElement('div'); d.textContent=s; return d.innerHTML; }
function showMsg(id, msg) { const e=document.getElementById(id); e.textContent=msg; setTimeout(function(){e.textContent='';},3000); }
function getApiKey() { return localStorage.getItem('plaintalk_apikey') || ''; }

document.addEventListener('DOMContentLoaded', function() {
    loadReminders(); loadMusic(); loadNewsList(); loadBooksList();
    loadPhotos(); loadActivity(); loadPatientInfo(); loadSettings(); loadUsageStats();
    var k = getApiKey();
    if (k) document.getElementById('apiKeyInput').value = k;
});

function showSection(n) {
    document.querySelectorAll('.content-section').forEach(function(s){s.classList.remove('active');});
    document.querySelectorAll('.nav-item').forEach(function(b){b.classList.remove('active');});
    document.getElementById('section-'+n).classList.add('active');
    document.querySelector('.nav-item[data-section="'+n+'"]').classList.add('active');
    document.getElementById('sidebar').classList.remove('open');
}
function toggleSidebar() { document.getElementById('sidebar').classList.toggle('open'); }
function toggleApiConfig() {
    var a = document.getElementById('apiConfigArea');
    var arrow = document.getElementById('apiToggleArrow');
    if (a.style.display === 'none') { a.style.display='block'; arrow.textContent='▾'; }
    else { a.style.display='none'; arrow.textContent='▸'; }
}
function saveApiKey() {
    var k = document.getElementById('apiKeyInput').value.trim();
    if (!k) { alert('Enter an API key.'); return; }
    localStorage.setItem('plaintalk_apikey', k);
    showMsg('apiKeySaveConfirm', '✓ Key saved.');
}

function addReminder() {
    var t = document.getElementById('reminderTime').value;
    var txt = document.getElementById('reminderText').value.trim();
    if (!t||!txt) { alert('Set both time and message.'); return; }
    var d = getData();
    d.reminders.push({time:t, text:txt, completed:false});
    d.reminders.sort(function(a,b){return a.time.localeCompare(b.time);});
    save(d);
    document.getElementById('reminderTime').value='';
    document.getElementById('reminderText').value='';
    loadReminders();
}
function deleteReminder(i) { var d=getData(); d.reminders.splice(i,1); save(d); loadReminders(); }
function loadReminders() {
    var d=getData(), c=document.getElementById('remindersList'), r=d.reminders||[];
    if (!r.length) { c.innerHTML='<p class="empty-state">No reminders yet.</p>'; return; }
    var html = '';
    for (var i=0; i<r.length; i++) {
        var rem = r[i];
        var parts = rem.time.split(':');
        var hr = parseInt(parts[0]);
        var mn = parts[1];
        var ampm = hr>=12?'PM':'AM';
        var h12 = hr===0?12:hr>12?hr-12:hr;
        html += '<div class="reminder-item '+(rem.completed?'completed':'')+'">' +
            '<span class="reminder-time">'+h12+':'+mn+' '+ampm+'</span>' +
            '<span class="reminder-text-label">'+esc(rem.text)+'</span>' +
            '<span class="reminder-status '+(rem.completed?'status-done':'status-pending')+'">'+(rem.completed?'✓ Done':'Pending')+'</span>' +
            '<button class="reminder-delete" onclick="deleteReminder('+i+')" title="Delete">✕</button></div>';
    }
    c.innerHTML = html;
}

function loadMusic() {
    var d=getData();
    if (d.music && d.music.selectedSong) {
        for (var i=0; i<SONGS.length; i++) {
            if (SONGS[i].name === d.music.selectedSong.name) {
                var r=document.querySelector('input[name="song"][value="'+i+'"]');
                if(r) r.checked=true;
                break;
            }
        }
    }
}
function saveMusic() {
    var s=document.querySelector('input[name="song"]:checked');
    if (!s) { alert('Select a song.'); return; }
    var idx = parseInt(s.value);
    var d=getData(); d.music.selectedSong=SONGS[idx]; save(d);
    showMsg('musicSaveConfirm', '✓ "'+SONGS[idx].name+'" saved.');
}

function fallbackSimplify(text, type) {
    var replacements = {
        'approximately':'about', 'subsequently':'then', 'consequently':'so',
        'furthermore':'also', 'nevertheless':'but', 'however':'but',
        'therefore':'so', 'additional':'more', 'sufficient':'enough',
        'regarding':'about', 'utilize':'use', 'implement':'do',
        'facilitate':'help', 'commence':'start', 'terminate':'end',
        'endeavour':'try', 'endeavor':'try', 'acquire':'get',
        'demonstrate':'show', 'significant':'big', 'numerous':'many',
        'immediately':'now', 'currently':'now', 'previously':'before',
        'manufacture':'make', 'purchase':'buy', 'residence':'home',
        'vehicle':'car', 'beverage':'drink', 'precipitation':'rain',
        'temperature':'how warm it is', 'legislation':'law',
        'authorities':'leaders', 'infrastructure':'roads and buildings',
        'administration':'government', 'unanimous':'everyone agreed',
        'referendum':'vote', 'constituency':'area', 'biodiversity':'nature',
        'sustainability':'looking after the planet', 'inflation':'prices going up',
        'recession':'money problems', 'parliamentary':'government',
        'unprecedented':'never happened before', 'controversial':'some people disagree',
        'deteriorate':'get worse', 'ameliorate':'get better', 'exacerbate':'make worse',
        'proliferate':'spread', 'perpetuate':'keep going', 'mitigate':'reduce',
        'collaborate':'work together', 'inaugurate':'open', 'reiterate':'say again',
        'fluctuate':'go up and down', 'anticipate':'expect', 'accommodate':'fit',
        'preliminary':'early', 'comprehensive':'full', 'inevitable':'sure to happen',
        'substantial':'large', 'subsequent':'next', 'preliminary':'first',
        'mandatory':'must do', 'voluntary':'by choice', 'temporary':'for now',
        'permanent':'forever', 'adequate':'enough', 'excessive':'too much',
        'consecutive':'in a row', 'simultaneous':'at the same time',
        'deteriorating':'getting worse', 'escalating':'growing',
        'diminishing':'shrinking', 'fluctuating':'changing'
    };

    var result = text;
    for (var word in replacements) {
        var regex = new RegExp('\\b' + word + '\\b', 'gi');
        result = result.replace(regex, replacements[word]);
    }

    var sentences = result.replace(/\n+/g, '. ').replace(/([.!?])\s*/g, '$1|').split('|').filter(function(s){return s.trim().length > 0;});

    var simplified = [];
    for (var i=0; i<sentences.length; i++) {
        var s = sentences[i].trim();
        if (s.split(' ').length > 12) {
            var parts = s.split(/,\s*/);
            if (parts.length > 1) {
                for (var j=0; j<parts.length; j++) {
                    var p = parts[j].trim();
                    if (p.length > 0) {
                        if (!p.match(/[.!?]$/)) p += '.';
                        p = p.charAt(0).toUpperCase() + p.slice(1);
                        simplified.push(p);
                    }
                }
            } else {
                simplified.push(s);
            }
        } else {
            simplified.push(s);
        }
    }

    return simplified.join('\n\n');
}

function simplifyText(text, type) {
    var apiKey = getApiKey();
    if (!apiKey) {
        return Promise.resolve(fallbackSimplify(text, type));
    }

    var systemPrompt;
    if (type === 'newspaper') {
        systemPrompt = 'You are PlainTalk, a text simplifier for elderly dementia patients (aged 75-85). Rewrite the following newspaper article in very simple, plain English.\n\nRules:\n- Use short sentences (maximum 8-10 words each)\n- No jargon, no acronyms, no complex words\n- Use everyday language a young child could understand\n- Keep the key facts\n- Use a warm, calm tone\n- Add blank lines between paragraphs\n- Do NOT include any headers, bullet points, or formatting\n- Just write simple sentences, one after another';
    } else {
        systemPrompt = 'You are PlainTalk. Rewrite this as a bedtime story suitable for ages 3-6 and also suitable for elderly dementia patients.\n\nRules:\n- Very simple words only\n- Short sentences (max 8 words)\n- Warm, soothing, gentle tone\n- Add blank lines between paragraphs\n- Like a picture book with no pictures\n- Repetition is fine and helpful';
    }

    return fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: { 'Content-Type':'application/json', 'Authorization':'Bearer '+apiKey },
        body: JSON.stringify({
            model: 'gpt-4o-mini',
            messages: [
                { role:'system', content: systemPrompt },
                { role:'user', content: text }
            ],
            max_tokens: 1000,
            temperature: 0.4
        })
    }).then(function(res) {
        if (!res.ok) {
            return res.json().catch(function(){return {};}).then(function(err) {
                throw new Error(err.error ? err.error.message : 'API error ' + res.status);
            });
        }
        return res.json();
    }).then(function(data) {
        return data.choices[0].message.content.trim();
    }).catch(function(err) {
        console.warn('API failed, using fallback:', err.message);
        return fallbackSimplify(text, type);
    });
}

function simplifyAndAddNews() {
    var title = document.getElementById('newsTitle').value.trim();
    var text = document.getElementById('newsText').value.trim();
    if (!title || !text) { alert('Enter both a title and article text.'); return; }

    document.getElementById('newsSpinner').style.display = 'flex';
    document.getElementById('simplifyBtn').disabled = true;

    simplifyText(text, 'newspaper').then(function(simplified) {
        var d = getData();
        if (!d.reading) d.reading = {newspapers:[],books:[]};
        if (!d.reading.newspapers) d.reading.newspapers = [];
        d.reading.newspapers.push({ title:title, content:simplified, original:text });
        save(d);
        document.getElementById('newsTitle').value = '';
        document.getElementById('newsText').value = '';
        loadNewsList();
        showMsg('newsSaveConfirm', '✓ Article simplified and added!');
    }).catch(function(e) {
        alert('Error: ' + e.message);
    }).finally(function() {
        document.getElementById('newsSpinner').style.display = 'none';
        document.getElementById('simplifyBtn').disabled = false;
    });
}

function simplifyAndAddBook() {
    var title = document.getElementById('bookTitle').value.trim();
    var text = document.getElementById('bookText').value.trim();
    if (!title || !text) { alert('Enter both a title and story text.'); return; }

    document.getElementById('bookSpinner').style.display = 'flex';

    simplifyText(text, 'book').then(function(simplified) {
        var d = getData();
        if (!d.reading) d.reading = {newspapers:[],books:[]};
        if (!d.reading.books) d.reading.books = [];
        d.reading.books.push({ title:title, content:simplified });
        save(d);
        document.getElementById('bookTitle').value = '';
        document.getElementById('bookText').value = '';
        loadBooksList();
        showMsg('bookSaveConfirm', '✓ Story simplified and added!');
    }).catch(function(e) {
        alert('Error: ' + e.message);
    }).finally(function() {
        document.getElementById('bookSpinner').style.display = 'none';
    });
}

function deleteNews(i) { var d=getData(); d.reading.newspapers.splice(i,1); save(d); loadNewsList(); }
function deleteBook(i) { var d=getData(); d.reading.books.splice(i,1); save(d); loadBooksList(); }

function loadNewsList() {
    var d=getData(), c=document.getElementById('newsList'), items=(d.reading&&d.reading.newspapers)||[];
    if (!items.length) { c.innerHTML=''; return; }
    var html='';
    for (var i=0;i<items.length;i++) {
        html += '<div class="item-entry"><div class="item-entry-content"><strong>📰 '+esc(items[i].title)+'</strong>' +
        '<p>'+esc(items[i].content).substring(0,120)+'...</p></div>' +
        '<button class="item-delete" onclick="deleteNews('+i+')" title="Remove">✕</button></div>';
    }
    c.innerHTML = html;
}
function loadBooksList() {
    var d=getData(), c=document.getElementById('booksList'), items=(d.reading&&d.reading.books)||[];
    if (!items.length) { c.innerHTML=''; return; }
    var html='';
    for (var i=0;i<items.length;i++) {
        html += '<div class="item-entry"><div class="item-entry-content"><strong>📖 '+esc(items[i].title)+'</strong>' +
        '<p>'+esc(items[i].content).substring(0,120)+'...</p></div>' +
        '<button class="item-delete" onclick="deleteBook('+i+')" title="Remove">✕</button></div>';
    }
    c.innerHTML = html;
}

function addPhoto() {
    var u = document.getElementById('photoUrl').value.trim();
    if (!u) { alert('Enter a photo URL.'); return; }
    var d = getData();
    if (!d.album) d.album={photos:[]};
    d.album.photos.push(u);
    save(d);
    document.getElementById('photoUrl').value='';
    loadPhotos();
}
function deletePhoto(i) { var d=getData(); d.album.photos.splice(i,1); save(d); loadPhotos(); }
function loadPhotos() {
    var d=getData(), g=document.getElementById('photosList'), photos=(d.album&&d.album.photos)||[];
    if (!photos.length) { g.innerHTML='<p class="empty-state">No photos yet.</p>'; return; }
    var html='';
    for (var i=0;i<photos.length;i++) {
        html += '<div class="photo-item"><img src="'+esc(photos[i])+'" alt="Photo" onerror="this.style.display=\'none\'">' +
        '<button class="photo-delete" onclick="deletePhoto('+i+')">✕</button></div>';
    }
    g.innerHTML = html;
}

function loadActivity() {
    var d=getData();
    if (d.activity&&d.activity.title) document.getElementById('activityTitle').value=d.activity.title;
    if (d.activity&&d.activity.steps&&d.activity.steps.length) document.getElementById('activityStepsInput').value=d.activity.steps.join('\n');
}
function saveActivity() {
    var title=document.getElementById('activityTitle').value.trim();
    var raw=document.getElementById('activityStepsInput').value.trim();
    if (!title||!raw) { alert('Enter a name and steps.'); return; }
    var steps = raw.split('\n').map(function(s){return s.trim();}).filter(function(s){return s.length>0;});
    var d=getData(); d.activity={title:title,steps:steps}; save(d);
    showMsg('activitySaveConfirm', '✓ Activity saved! ('+steps.length+' steps)');
}

function loadPatientInfo() {
    var d=getData(), p=d.patientInfo||{};
    if (p.name) document.getElementById('piName').value=p.name;
    if (p.age) document.getElementById('piAge').value=p.age;
    if (p.diagnosis) document.getElementById('piDiagnosis').value=p.diagnosis;
    if (p.notes) document.getElementById('piNotes').value=p.notes;
}
function savePatientInfo() {
    var d=getData();
    d.patientInfo = {
        name:document.getElementById('piName').value.trim(),
        age:document.getElementById('piAge').value.trim(),
        diagnosis:document.getElementById('piDiagnosis').value.trim(),
        notes:document.getElementById('piNotes').value.trim()
    };
    save(d); showMsg('piSaveConfirm','✓ Patient info saved.');
}
function loadUsageStats() {
    var d=getData(), u=d.usage||{music:0,album:0,activity:0,reading:0};
    var mx = Math.max(u.music,u.album,u.activity,u.reading,1);
    document.getElementById('statMusic').style.width=((u.music/mx)*100)+'%';
    document.getElementById('statMusicVal').textContent=u.music;
    document.getElementById('statAlbum').style.width=((u.album/mx)*100)+'%';
    document.getElementById('statAlbumVal').textContent=u.album;
    document.getElementById('statActivity').style.width=((u.activity/mx)*100)+'%';
    document.getElementById('statActivityVal').textContent=u.activity;
    document.getElementById('statReading').style.width=((u.reading/mx)*100)+'%';
    document.getElementById('statReadingVal').textContent=u.reading;
}

function loadSettings() {
    var d=getData();
    if (d.patientName) document.getElementById('settingName').value=d.patientName;
    if (d.emergencyContact) document.getElementById('settingPhone').value=d.emergencyContact.replace('tel:','');
}
function saveSettings() {
    var name=document.getElementById('settingName').value.trim();
    var phone=document.getElementById('settingPhone').value.trim();
    var d=getData();
    if (name) d.patientName=name;
    if (phone) d.emergencyContact='tel:'+phone.replace(/\s/g,'');
    save(d);
    showMsg('settingsSaveConfirm','✓ Settings saved.');
}
function resetAllData() {
    if (confirm('Are you sure? This will delete ALL data.')) {
        localStorage.removeItem('plaintalk_admin');
        localStorage.removeItem('plaintalk_apikey');
        localStorage.removeItem('plaintalk_mode');
        sessionStorage.removeItem('plaintalk_dismissed');
        location.reload();
    }
}
